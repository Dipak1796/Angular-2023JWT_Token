export class Jwtresponse {
    role:number=0;
    emailId:string='';
    accessToken:string='';
}
